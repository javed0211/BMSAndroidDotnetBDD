﻿using OpenQA.Selenium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Enums;
using OpenQA.Selenium.Appium.Service;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace BookMyShowAndroid.Steps
{
    [Binding]
    public class BMSSteps : BaseSteps
    {
        [Given(@"I am on Book my show app")]
        public void GivenIAmOnBookMyShowWebsite()
        {
            InitializeTest();
            Thread.Sleep(10000);
            AndroidContext.FindElement(By.ClassName("android.widget.TextView")).Click();            
        }

        [When(@"I click on Movies link")]
        public void WhenIClickOnMoviesLink()
        {
            ScenarioContext.Current.Pending();
        }

        [When(@"I choose Thugs of Hindostan")]
        public void WhenIChooseThugsOfHindostan()
        {
            ScenarioContext.Current.Pending();
        }

        [When(@"I click on book tickets button")]
        public void WhenIClickOnBookTicketsButton()
        {
            ScenarioContext.Current.Pending();
        }

        [When(@"I select (.*) show of INOX: Inorbit Mall Malad")]
        public void WhenISelectShowOfINOXInorbitMallMalad(string p0)
        {
            ScenarioContext.Current.Pending();
        }

        [When(@"I accept terms & conditions")]
        public void WhenIAcceptTermsConditions()
        {
            ScenarioContext.Current.Pending();
        }

        [When(@"I choose '(.*)' tickets")]
        public void WhenIChooseTickets(int p0)
        {
            ScenarioContext.Current.Pending();
        }

        [When(@"I choose seat")]
        public void WhenIChooseSeat()
        {
            ScenarioContext.Current.Pending();
        }

        [When(@"I click on Pay button")]
        public void WhenIClickOnPayButton()
        {
            ScenarioContext.Current.Pending();
        }

        [When(@"I select '(.*)'")]
        public void WhenISelect(string p0)
        {
            ScenarioContext.Current.Pending();
        }

        [When(@"I click on Proceed button")]
        public void WhenIClickOnProceedButton()
        {
            ScenarioContext.Current.Pending();
        }

        [When(@"I enter contact details")]
        public void WhenIEnterContactDetails()
        {
            ScenarioContext.Current.Pending();
        }

    }
}
