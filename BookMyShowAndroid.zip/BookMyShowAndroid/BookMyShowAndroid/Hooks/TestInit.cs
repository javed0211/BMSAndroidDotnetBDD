﻿using OpenQA.Selenium.Appium.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace BookMyShowAndroid.Hooks
{
    class TestInit
    {
        [AfterScenario]
        public void CloseAppiumServer()
        {
            AppiumLocalService _appiumLocalService = (AppiumLocalService)ScenarioContext.Current["_appiumLocalService"];
            _appiumLocalService.Dispose();
        }
    }
}
