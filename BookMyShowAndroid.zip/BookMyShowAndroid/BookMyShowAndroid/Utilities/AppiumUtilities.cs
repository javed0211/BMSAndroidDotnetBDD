﻿using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Enums;
using OpenQA.Selenium.Appium.Service;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace BookMyShowAndroid.Utilities
{
   public class AppiumUtilities :Base
    {
        private AppiumLocalService _appiumLocalService;
        private AndroidDriver<AndroidElement> _androidDriver;

        public AppiumUtilities(AppiumLocalService appiumLocalService, AndroidDriver<AndroidElement> androidDriver)
        {
            _appiumLocalService = appiumLocalService;
            _androidDriver = androidDriver;
        }

        public AndroidDriver<AndroidElement> InitializeAndroidHybridApp()
        {
            DesiredCapabilities desiredCaps = new DesiredCapabilities();
            desiredCaps.SetCapability(MobileCapabilityType.PlatformName, "Android");
            desiredCaps.SetCapability(MobileCapabilityType.DeviceName, "Pixel API 27");
            desiredCaps.SetCapability(MobileCapabilityType.App, @"C:\Users\javed\Downloads\Android App - 5.4.17\5.4.17 (3)\BookMyShow-x86-release.apk");

            //desiredCaps.SetCapability("appPackage", "com.bt.bms");
            AndroidDriver<AndroidElement> androidDriver = new AndroidDriver<AndroidElement>(_appiumLocalService, desiredCaps);

            //androidDriver.Context = androidDriver.Contexts.First(x => x.Contains("com.bt.bms:id/language_text_view_label"));

            return androidDriver;

        }

        public AppiumLocalService StartAppiumLocalService()
        {
            _appiumLocalService = new AppiumServiceBuilder().UsingAnyFreePort().Build();
            if (_appiumLocalService.IsRunning)
                _appiumLocalService.Start();

            return _appiumLocalService;
        }

        public AppiumLocalService StartAppiumLocalService(int portNumber)
        {
            _appiumLocalService = new AppiumServiceBuilder().UsingPort(portNumber).Build();
            if (_appiumLocalService.IsRunning)
                _appiumLocalService.Start();

            ScenarioContext.Current["_appiumLocalService"] = _appiumLocalService;
            return _appiumLocalService;
            
        }

        public void CloseAppiumServer()
        {
            _androidDriver.Close();
        }
    }
}
