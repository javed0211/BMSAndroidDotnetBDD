﻿using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMyShowAndroid.Utilities
{
    public class Base
    {
        public AppiumLocalService AppiumServiceContext;

        public AndroidDriver<AndroidElement> AndroidContext;

        public AppiumUtilities appUti => new AppiumUtilities(AppiumServiceContext, AndroidContext);


        public AndroidDriver<AndroidElement> StartAppiumServerForHybrid()
        {
            AppiumServiceContext = appUti.StartAppiumLocalService();

            AndroidContext = appUti.InitializeAndroidHybridApp();

            return AndroidContext;
        }
    }
}
